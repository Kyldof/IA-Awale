import awale as aw


# fonction renvoyant la position à jouer
def ia(jeu, joueur):
    # on fait une copie du jeu afin de ne pas le modifier
    jeu_copie = jeu.copy()
    # initialisation de la profondeur pour prédire les coups
    depth = 5
    caillou, pos = max_awale(jeu_copie, joueur, depth)
    return pos


# fonction recherchant le coup optimal pour l'ia
def max_awale(jeu_copie, joueur, depth):
    # on crée un backup afin d'essayer tous les coups disponibles et de pouvoir revenir à la situation de départ
    jeu_backup = jeu_copie.copy()
    # on initialise le max_caillou à une valeur très faible, car l'ia recherche un score positif élevé
    max_caillou = -100
    pos = None

    # si le jeu est terminé, renvoie l'issu du score et la position 0
    if aw.jeu_est_termine(jeu_copie):
        aw.jeu_ramasser_billes(jeu_copie)
        grenier1 = aw.jeu_grenier(jeu_copie, joueur)
        grenier2 = aw.jeu_grenier(jeu_copie, aw.adversaire(joueur))
        score = grenier1 - grenier2
        return score, 0

    # si la profondeur est terminée :
    if depth == 0:
        # essaie tous les trous possibles
        for i in range(1, 7):
            # vérifie si le joueur peut jouer
            if aw.joueur_peut_jouer_trou(jeu_copie, joueur, i):
                aw.joue(jeu_copie, joueur, i)
                # calcul le nombre de cailloux gagné
                grenier1 = aw.jeu_grenier(jeu_copie, joueur)
                grenier2 = aw.jeu_grenier(jeu_copie, aw.adversaire(joueur))
                score = grenier1 - grenier2
                # si le score est plus élevé que ceux trouvé avant, on sauvegarde le score et la position
                if score > max_caillou:
                    max_caillou = score
                    pos = i
                # on remet le jeu à sa position précédente pour essayer d'autres coups
                jeu_copie = jeu_backup.copy()
        # renvoie le max cailloux et la position
        return max_caillou, pos

    else:
        # essaie tous les trous possibles
        for i in range(1, 7):
            # vérifie si le joueur peut jouer
            if aw.joueur_peut_jouer_trou(jeu_copie, joueur, i):
                aw.joue(jeu_copie, joueur, i)
                # appelle de la fonction min pour trouver le meilleur coup adverse et réduction de 1 de la profondeur
                caillou, pos_min = min_awale(jeu_copie, aw.adversaire(joueur), depth - 1)
                # si le nombre de cailloux gagné est supérieur au max cailloux, on sauvegarde le score et la position
                if caillou > max_caillou:
                    max_caillou = caillou
                    pos = i
                # on remet le jeu à sa position précédente pour essayer d'autres coups
                jeu_copie = jeu_backup.copy()
        # renvoie le max cailloux et la position
        return max_caillou, pos


# fonction recherchant le coup optimal pour l'adversaire
def min_awale(jeu_copie, joueur, depth):
    # on crée un backup afin d'essayer tous les coups disponibles et de pouvoir revenir à la situation de départ
    jeu_backup = jeu_copie.copy()
    # on initialise le min_cailloux à une valeur très élevé, car l'adversaire recherche un score très faible (négatif)
    min_cailloux = 100
    pos = None

    # si le jeu est terminé, renvoie l'issu du score et la position 0
    if aw.jeu_est_termine(jeu_copie):
        aw.jeu_ramasser_billes(jeu_copie)
        grenier2 = aw.jeu_grenier(jeu_copie, joueur)
        grenier1 = aw.jeu_grenier(jeu_copie, aw.adversaire(joueur))
        score = grenier1 - grenier2
        return score, 0

    # si la profondeur est terminée :
    if depth == 0:
        # essaie tous les trous possibles
        for i in range(1, 7):
            # vérifie si le joueur peut jouer
            if aw.joueur_peut_jouer_trou(jeu_copie, joueur, i):
                aw.joue(jeu_copie, joueur, i)
                # calcul le nombre de cailloux gagné
                grenier1 = aw.jeu_grenier(jeu_copie, aw.adversaire(joueur))
                grenier2 = aw.jeu_grenier(jeu_copie, joueur)
                score = grenier1 - grenier2
                # si le score est plus bas que ceux trouvé avant, on sauvegarde le score et la position
                if score < min_cailloux:
                    min_cailloux = score
                    pos = i
                # on remet le jeu à sa position précédente pour essayer d'autres coups
                jeu_copie = jeu_backup.copy()
        # renvoie le min cailloux et la position
        return min_cailloux, pos

    else:
        # essaie tous les trous possibles
        for i in range(1, 7):
            # vérifie si le joueur peut jouer
            if aw.joueur_peut_jouer_trou(jeu_copie, joueur, i):
                aw.joue(jeu_copie, joueur, i)
                # appelle de la fonction max pour trouver le meilleur coup de l'ia et réduction de 1 de la profondeur
                caillou, pos_max = max_awale(jeu_copie, aw.adversaire(joueur), depth - 1)
                # si le nombre de cailloux gagné est inférieur au min cailloux, on sauvegarde le score et la position
                if caillou < min_cailloux:
                    min_cailloux = caillou
                    pos = i
                # on remet le jeu à sa position précédente pour essayer d'autres coups
                jeu_copie = jeu_backup.copy()
        # renvoie le max cailloux et la position
        return min_cailloux, pos
