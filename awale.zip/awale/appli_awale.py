import numpy as np
import awale as aw
import ia1 as ia

le_joueur_courant = aw.JOUEUR_1
le_jeu = aw.jeu_initialiser()

print(" ______   __  _  ____   ___     _     ___    _    _   _                   _   __  __    _    ____ _____ ___ _   _ ")
print("| __ ) \ / / | |/ /\ \ / / |   | |   |_ _|  / \  | \ | |   __ _ _ __   __| | |  \/  |  / \  |  _ \_   _|_ _| \ | |")
print(r"|  _ \\ V /  | ' /  \ V /| |   | |    | |  / _ \ |  \| |  / _` | '_ \ / _` | | |\/| | / _ \ | |_) || |  | ||  \| |")
print("| |_) || |   | . \   | | | |___| |___ | | / ___ \| |\  | | (_| | | | | (_| | | |  | |/ ___ \|  _ < | |  | || |\  |")
print("|____/ |_|   |_|\_\  |_| |_____|_____|___/_/   \_\_| \_|  \__,_|_| |_|\__,_| |_|  |_/_/   \_\_| \_\|_| |___|_| \_|")
print("༼ つ ◕_◕ ༽つ")

def demande(jeu, joueur):
    n = 0
    while True:
        print("quel trou jouer joueur ", joueur, " ? ", end='')
        n = int(input())
        if aw.joueur_peut_jouer_trou(jeu, joueur, n):
            break
    return n


tour = 1

while not aw.jeu_est_termine(le_jeu):

    print("༼ つ ◕_◕ ༽つ")
    print("tour : ", tour)
    tour += 1
    aw.jeu_afficher(le_jeu)

    if aw.joueur_peut_jouer(le_jeu, le_joueur_courant):

        if le_joueur_courant == aw.JOUEUR_1:
            # Pour faire un 1V1 changer le 'ia.ia' par 'demande'
            trou = ia.ia(le_jeu, le_joueur_courant)
            print("Joueur 1 joue case n° ", trou)
            aw.joue(le_jeu, le_joueur_courant, trou)

        if le_joueur_courant == aw.JOUEUR_2:
            # pour que les 2 ia se jouent entre elles changer le 'demande' par 'ia.ia'
            trou = demande(le_jeu, le_joueur_courant)
            print("Joueur 2 joue case n° ", trou)
            aw.joue(le_jeu, le_joueur_courant, trou)

    else:
        print("Le joueur ", le_joueur_courant, " ne peut pas jouer")

    le_joueur_courant = aw.adversaire(le_joueur_courant)

    print("__________________________")

aw.jeu_ramasser_billes(le_jeu)
aw.jeu_afficher(le_jeu)
grenier_1 = aw.jeu_grenier(le_jeu, aw.JOUEUR_1)
grenier_2 = aw.jeu_grenier(le_jeu, aw.JOUEUR_2)
if grenier_1 > grenier_2:
    print("Joueur 1 a gagné !")
elif grenier_2 > grenier_1:
    print("Joueur 2 a gagné !")
else:
    print("Match nul")
