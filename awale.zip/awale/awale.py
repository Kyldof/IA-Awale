import numpy as np

# premier joueur
JOUEUR_1 = 1
# second joueur
JOUEUR_2 = 2
# nombre de trous / cases
MAX_TROUS = 14


def jeu_initialiser():
    """
    --------------------------
    return list or numpy array
    --------------------------

    # Initialisation du jeu sous forme de tableau numpy
    # dont le premier indice ne sert à rien
    # On peut également utiliser une simple liste

    """
    return np.array( [ 0, 4, 4, 4, 4, 4, 4, 0, 4, 4, 4, 4, 4, 4, 0 ] )
    #return np.array([ 0, 0, 0, 3, 3, 0, 1, 14, 0, 0, 0, 0, 2, 10, 15 ])


def adversaire( joueur ):
    """
    -------------------------
    joueur : int (1 ou 2)
    return int
    -------------------------

    #retourne le chiffre qui correspond à l'adversaire du joueur

    """
    if joueur == JOUEUR_1 : return JOUEUR_2
    else : return JOUEUR_1



def trou_suivant( trou,  joueur ):
    """
    --------------------------
    trou : int (entre 1 et 14)
    joueur : int (1 ou 2)
    return int (entre 1 et 14)
    --------------------------



    # Retourne le trou suivant accessible en fonction du trou
    # d'où on commence et du joueur. On rappelle qu'un joueur
    # ne peut pas jouer dans le grenier de son adversaire

    """
    if trou == 6:
        if joueur == JOUEUR_2 : return 8
        else : return trou + 1
    elif trou == 13:
        if joueur == JOUEUR_1: return 1
        else : return trou + 1
    elif trou == 14:
        return 1
    else : return trou + 1


def jeu_afficher(jeu):
    """
    -------------------------
    jeu : list or numpy array
    -------------------------

    # affiche le plateau de jeu

    """
    print("J2:       <--")
    print("    6  5  4  3  2  1")
    print("   ", end="")
    for i in range(13, 7, -1):  # (13, 7, -1)
        print("|" + str(jeu[i]) + "|", end="")
    print("")
    print("|" + str(jeu[14]) + "|", end="")
    for _ in range(18): print(" ", end="")
    print("|" + str(jeu[7]) + "|")
    print("   ", end="")
    for i in range(1, 7):
        print("|" + str(jeu[i]) + "|", end="")
    print("")
    print("    1  2  3  4  5  6")
    print("J1:       -->")



def jeu_est_termine( jeu ):
    """
    -------------------------
    jeu : list or numpy array
    return bool
    -------------------------

    # Indique si le jeu est terminé (True), c'est à dire si l'un des
    # joueurs ne peut pas jouer

    """

    somme_joueur = 0
    for i in range (1, 7):
        somme_joueur += jeu[i]
    if somme_joueur == 0 : return True
    else :
        somme_joueur = 0
        for i in range(8, 14):
            somme_joueur += jeu[i]
        if somme_joueur == 0 : return True
        else : return False








def jeu_ramasser_billes( jeu ):
    """
    -------------------------
    jeu : list or numpy array
    -------------------------

    # Si on termine le jeu on ramasse les billes restantes
    # et on les place dans le grenier du joueur concerné

    """


    # on initialise une variable score à 0
    score = 0
    # on additionne les points des cases du premier joueur
    for i in range (1,7):
        score += jeu[i]
        jeu[i] = 0
    # si le score est égal à 0 alors le joueur 2 a gagné
    if score == 0:
        # et on ajoute donc les cailloux restant dans le grenier du joueur 2
        for i in range (8,14):
            score += jeu[i]
            jeu[i] = 0
        jeu[14] += score
    # sinon on ajoute les cailloux restant dans le grenier du joueur
    # 1 étant donné qu'il est gagnant
    else:
        jeu[7] += score


def joueur_peut_jouer( jeu, joueur ):
    """
    -------------------------
    jeu : list or numpy array
    joueur : int (1 ou 2)

    return jouable : bool
    -------------------------

    # Indique si un joueur peut jouer, c'est à dire qu'il possède

    """
    jouable = False
    if joueur == JOUEUR_1:
        for i in range (1,7):
            if jeu[i] > 0:
                jouable = True
    else:
        for i in range (8,14):
            if jeu[i] > 0:
                jouable = True
    return jouable



def joueur_peut_jouer_trou( jeu, joueur, trou ):
    """
    -------------------------
    jeu : list or numpy array
    joueur : int (1 ou 2)
    trou : int (entre 1 et 6)
    return jouable : bool
    -------------------------

    # Indique si le joueur peut jouer la case/trou indiqué

    """
    jouable = False
    if 0 < trou < 7:
        if joueur == JOUEUR_1:
            if jeu[trou] > 0:
                jouable = True
        else:
            if jeu[trou + 7] > 0:
                    jouable = True
    return jouable


def joue( jeu, joueur, trou ):
    """
    -------------------------
    jeu : list or numpy array
    joueur : int
    trou : int (entre 1 et 6)
    -------------------------

    # Joue pour le joueur donné, le coup donné

    """
    if joueur == JOUEUR_2 : trou += 7
    nb_caillou = jeu[trou]
    jeu[trou] = 0
    while nb_caillou > 0:
        trou = trou_suivant(trou,joueur)
        jeu[trou] += 1
        nb_caillou -= 1
    if joueur == JOUEUR_1 and 1 <= trou <= 6:
        if jeu[trou] == 1:
            # prend le trou opposé (celui de l'adversaire)
            trou_opp = abs(7-trou)+7
            jeu[7] += jeu[trou_opp]
            jeu[trou_opp] = 0

    if joueur == JOUEUR_2 and 8 <= trou <= 13:
        if jeu[trou] == 1:
            # prend le trou opposé (celui de l'adversaire)
            trou_opp = trou - ((trou-7) *2)
            jeu[14] += jeu[trou_opp]
            jeu[trou_opp] = 0



def jeu_grenier( jeu, joueur ):
    """
    -------------------------
    jeu : array list
    joeur : int
    -------------------------

    # retourne le nombre de billes dans le grenier du joueur donné

    """
    if joueur == JOUEUR_1:
        return jeu[7]
    else:
        return jeu[14]
